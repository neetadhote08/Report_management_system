import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';
import { Employee } from './employees';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  private baseUrl = 'http://localhost:8080';

  constructor(private http: HttpClient) { }

  addEmployee(employee: Object): Observable<Object> {
    console.log(Employee);
    return this.http.post(this.baseUrl+'/employee/register',employee);
  }

  loginEmployee(Employee:Object): Observable<any>{
    return this.http.post(this.baseUrl+'/employee/login',Employee)
  }

  updateRole(role:string,Employee:Object): Observable<Object>{
    return this.http.put(this.baseUrl+'/employee/updaterole/'+{role},Employee);
  }

  changePassword(newpass:string,Employee:Object): Observable<Object>{
    return this.http.put(this.baseUrl+'/employee/changepass/:newpass'+{newpass},Employee);
  }

}
