import { listLazyRoutes } from '@angular/compiler/src/aot/lazy_routes';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ReportService } from '../report.service';
import { Report } from '../reports';

@Component({
  selector: 'app-read-report-component',
  templateUrl: './read-report-component.component.html',
  styleUrls: ['./read-report-component.component.css']
})
export class ReadReportComponentComponent implements OnInit {

  id:number;
  report:Report;
  constructor(private route:ActivatedRoute,private router:Router,private reportservice:ReportService) { }

  ngOnInit(): void {
    this.report=new Report();
    this.reportservice.viewReport(this.id).subscribe(data=>{ console.log(data)
    this.report=data},error=>console.log(error));
  }
  list()
  {
    this.router.navigate(['reports/viewallreports'])
  }
}

