import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReadReportComponentComponent } from './read-report-component.component';

describe('ReadReportComponentComponent', () => {
  let component: ReadReportComponentComponent;
  let fixture: ComponentFixture<ReadReportComponentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ReadReportComponentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ReadReportComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
