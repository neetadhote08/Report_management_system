import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowAllreportsComponentComponent } from './show-allreports-component.component';

describe('ShowAllreportsComponentComponent', () => {
  let component: ShowAllreportsComponentComponent;
  let fixture: ComponentFixture<ShowAllreportsComponentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ShowAllreportsComponentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ShowAllreportsComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
