import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { ReportService } from '../report.service';
import { Report } from '../reports';

@Component({
  selector: 'app-show-allreports-component',
  templateUrl: './show-allreports-component.component.html',
  styleUrls: ['./show-allreports-component.component.css']
})
export class ShowAllreportsComponentComponent implements OnInit {

  constructor(private  router: Router,private reportService: ReportService) { }
  reports: Observable<Report[]>

  ngOnInit(): void {
    this.fetchallReports();
  }

  fetchallReports()
  {
    this.reports=this.reportService.viewAllReports();
  }

  viewdetails(id:number)
  {
   this.router.navigate(['reports/viewreports',id]);
  }
  

}
