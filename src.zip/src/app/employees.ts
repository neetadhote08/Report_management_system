
export class Employee {
empid:number;
empname:string;
email:string;
password:string;
role:string;

}