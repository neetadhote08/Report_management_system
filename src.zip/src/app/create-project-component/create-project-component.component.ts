import { Component, OnInit } from '@angular/core';
import {ProjectService} from '../project.service';
import {Router} from '@angular/router';
import {Project} from '../projects';

@Component({
  selector: 'app-create-project-component',
  templateUrl: './create-project-component.component.html',
  styleUrls: ['./create-project-component.component.css']
})
export class CreateProjectComponentComponent implements OnInit {

  constructor(private projectService: ProjectService, private router: Router) 
   { }
   
   project: Project=new Project();

  ngOnInit(): void {
  }

  saveProject(){
    this.projectService.addProject(this.project).subscribe(data => console.log(data),error => console.log(error));
    this.project=new Project();
    this.gotoProjectList();
  }
onSubmit()
{
  this.saveProject();
}
  gotoProjectList()
  {
    this.router.navigate(['/project/viewproject'])
  }



}
