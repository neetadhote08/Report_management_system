import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contactus-component',
  templateUrl: './contactus-component.component.html',
  styleUrls: ['./contactus-component.component.css']
})
export class ContactusComponentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
