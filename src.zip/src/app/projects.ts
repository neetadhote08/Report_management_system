export class Project{

    projid:number;
    projtitle:string;
    description:string;
    projectspan:number;
    deadline:any;

}