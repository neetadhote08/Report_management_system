import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReadProjectDetailsComponentComponent } from './read-project-details-component.component';

describe('ReadProjectDetailsComponentComponent', () => {
  let component: ReadProjectDetailsComponentComponent;
  let fixture: ComponentFixture<ReadProjectDetailsComponentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ReadProjectDetailsComponentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ReadProjectDetailsComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
