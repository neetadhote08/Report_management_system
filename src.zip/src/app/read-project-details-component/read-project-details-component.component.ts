import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ProjectService } from '../project.service';
import { Project } from '../projects';

@Component({
  selector: 'app-read-project-details-component',
  templateUrl: './read-project-details-component.component.html',
  styleUrls: ['./read-project-details-component.component.css']
})
export class ReadProjectDetailsComponentComponent implements OnInit {

  id:number;
  project:Project;
  constructor(private route: ActivatedRoute, private router: Router,
    private projectService: ProjectService) { }

  ngOnInit(): void {
    this.project=new Project();
    this.route.snapshot.params["id"];
    this.projectService.findProject(this.id).subscribe(data=>{console.log(data)
    this.project=data},error=>console.log(error));
  }
  list()
  {
    this.router.navigate[('project/viewallprojects')]
  }

}
