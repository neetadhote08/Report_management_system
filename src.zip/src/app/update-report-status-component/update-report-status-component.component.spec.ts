import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateReportStatusComponentComponent } from './update-report-status-component.component';

describe('UpdateReportStatusComponentComponent', () => {
  let component: UpdateReportStatusComponentComponent;
  let fixture: ComponentFixture<UpdateReportStatusComponentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UpdateReportStatusComponentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateReportStatusComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
