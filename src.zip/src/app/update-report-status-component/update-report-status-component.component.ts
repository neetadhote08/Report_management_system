import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-update-report-status-component',
  templateUrl: './update-report-status-component.component.html',
  styleUrls: ['./update-report-status-component.component.css']
})
export class UpdateReportStatusComponentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
