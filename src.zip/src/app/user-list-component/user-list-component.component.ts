import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user-list-component',
  templateUrl: './user-list-component.component.html',
  styleUrls: ['./user-list-component.component.css']
})
export class UserListComponentComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit(): void {
  }

  gotoAddReport()
  {
    this.router.navigate(['/reports/addreport']);
  }
  gotoViewAllReports()
  {
    this.router.navigate(['/reports/viewallreports']);
  }

}
