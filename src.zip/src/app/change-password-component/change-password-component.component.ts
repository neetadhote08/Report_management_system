import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { EmployeeService } from '../employee.service';
import { Employee } from '../employees';

@Component({
  selector: 'app-change-password-component',
  templateUrl: './change-password-component.component.html',
  styleUrls: ['./change-password-component.component.css']
})
export class ChangePasswordComponentComponent implements OnInit {

  constructor(private router: Router, private employeeeService:EmployeeService ) { }
  employee:Employee=new Employee();
  subset=(({email,password})=>({email,password}))(this.employee);
  newpass:string;
  ngOnInit(): void {
  }

  changePass()
  {
    let newpass=this.newpass;
  this.employeeeService.loginEmployee(this.subset).subscribe(data=>{ this.employee=data;
    //this.employee=new Employee();
    console.log(data)
    console.log(this.employee)
  },error=>console.log(error));
    console.log(this.employee);
    this.employeeeService.changePassword(newpass,this.employee).subscribe(data=>console.log(data),error=>console.log(error));
    this.gotoLogin();
  }
  onSubmit()
  {
    this.changePass();
  }
  gotoLogin()
  {
    this.router.navigate(['employees/login']);
  }

}
