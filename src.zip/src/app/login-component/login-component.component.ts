import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { EmployeeService } from '../employee.service';
import { Employee } from '../employees';

@Component({
  selector: 'app-login-component',
  templateUrl: './login-component.component.html',
  styleUrls: ['./login-component.component.css']
})
export class LoginComponentComponent implements OnInit {

  constructor(private employeeService: EmployeeService,private router: Router) { }
  employee:Employee=new Employee();
  subset=(({email,password})=>({email,password}))(this.employee);
  role='MENTOR';

  ngOnInit(): void {
  }

  loginData()
  {
    this.employeeService.loginEmployee(this.subset).subscribe(data=>{console.log(data)
    this.employee=data
  console.log(this.employee)},error=>console.log(error));
    this.employee=new Employee();
    if(this.employee.role===this.role)
    {
      console.log(this.employee)
      this.gotoMentor();
    }
    else if(this.employee===null)
    {
      this.redirectLogin()
    }
    else
    {
      console.log(this.employee)
      this.gotoUser();
  }
    }
   
  onSubmit()
  {
    this.loginData();
  }
  gotoMentor()
  {
    this.router.navigate(['/mentorlist']);
  }
  gotoUser()
  {
    this.router.navigate(['/userlist']);
  }

  gotoChangePassword()
  {
    this.router.navigate(['/employees/changepassword']);
  }
  redirectLogin()
  {
    this.router.navigate(['/employees/login']);
  }

}
