import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-mentor-list-component',
  templateUrl: './mentor-list-component.component.html',
  styleUrls: ['./mentor-list-component.component.css']
})
export class MentorListComponentComponent implements OnInit {

  constructor(private router:Router) { }

  ngOnInit(): void {
  }

  gotoAddReport()
  {
    this.router.navigate(['/reports/addreport']);
  }
  gotoViewAllReports()
  {
    this.router.navigate(['/reports/viewallreports']);
  }
  gotoViewPendingReports()
  {
    this.router.navigate(['reports/viewpengingreports'])
  }
  gotoAddProject()
  {
      this.router.navigate(['projects/addproject']);
  }
  gotoViewProjects()
  {
    this.router.navigate(['projects/viewallprojects']);
  }
}
