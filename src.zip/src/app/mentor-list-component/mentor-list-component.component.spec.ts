import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MentorListComponentComponent } from './mentor-list-component.component';

describe('MentorListComponentComponent', () => {
  let component: MentorListComponentComponent;
  let fixture: ComponentFixture<MentorListComponentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MentorListComponentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MentorListComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
