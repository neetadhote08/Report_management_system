import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { AppComponent } from './app.component';
import { CreateEmployeeComponentComponent } from './create-employee-component/create-employee-component.component';
import { CreateProjectComponentComponent } from './create-project-component/create-project-component.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ShowEmployeeComponent } from './show-employee/show-employee.component';
import { EmployeeService } from './employee.service';
import { ProjectService } from './project.service';
import { ReportService } from './report.service';
import { CreateReportComponentComponent } from './create-report-component/create-report-component.component';
import { ShowProjectComponentComponent } from './show-project-component/show-project-component.component';
import { ShowAllreportsComponentComponent } from './show-allreports-component/show-allreports-component.component';
import { ReadProjectDetailsComponentComponent } from './read-project-details-component/read-project-details-component.component';
import { ShowPendingReportsComponentComponent } from './show-pending-reports-component/show-pending-reports-component.component';
import { UpdateReportStatusComponentComponent } from './update-report-status-component/update-report-status-component.component';
import { ReadReportComponentComponent } from './read-report-component/read-report-component.component';
import { LoginComponentComponent } from './login-component/login-component.component';
import { UserListComponentComponent } from './user-list-component/user-list-component.component';
import { MentorListComponentComponent } from './mentor-list-component/mentor-list-component.component';
import { ChangePasswordComponentComponent } from './change-password-component/change-password-component.component';
import { AboutusComponentComponent } from './aboutus-component/aboutus-component.component';
import { ContactusComponentComponent } from './contactus-component/contactus-component.component';

@NgModule({
  declarations: [
    AppComponent,
    CreateEmployeeComponentComponent,
    CreateProjectComponentComponent,
    ShowEmployeeComponent,
    CreateReportComponentComponent,
    ShowProjectComponentComponent,
    ShowAllreportsComponentComponent,
    ReadProjectDetailsComponentComponent,
    ShowPendingReportsComponentComponent,
    UpdateReportStatusComponentComponent,
    ReadReportComponentComponent,
    LoginComponentComponent,
    UserListComponentComponent,
    MentorListComponentComponent,
    ChangePasswordComponentComponent,
    AboutusComponentComponent,
    ContactusComponentComponent
  ],
  imports: [ 
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    RouterModule.forRoot([
      {path:'employees/login',component:LoginComponentComponent},
      {path : 'employees/register', component: CreateEmployeeComponentComponent },
     //{path: '**', redirectTo:'employees/register'},
      {path: 'projects/addproject', component: CreateProjectComponentComponent},
      {path: 'reports/addreport',component:CreateReportComponentComponent},
      {path:'projects/viewallprojects',component:ShowProjectComponentComponent},
      {path:'projects/projectdetail/:id',component:ReadProjectDetailsComponentComponent},
      {path:'reports/viewallreports', component:ShowAllreportsComponentComponent},
      {path:'reports/viewreports/:id', component:ReadReportComponentComponent},
      {path:'userlist',component:UserListComponentComponent},
      {path:'mentorlist',component:MentorListComponentComponent},
      {path:'employees/changepassword',component:ChangePasswordComponentComponent},
      {path:'aboutus',component:AboutusComponentComponent},
      {path:'reports/viewpengingreports',component:ShowPendingReportsComponentComponent},
      {path:'contactus',component:ContactusComponentComponent}
       
    ])
  ],
  providers: [EmployeeService,
  ProjectService,
ReportService],
  bootstrap: [AppComponent]
})
export class AppModule { }
