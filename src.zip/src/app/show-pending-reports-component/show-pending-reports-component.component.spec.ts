import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowPendingReportsComponentComponent } from './show-pending-reports-component.component';

describe('ShowPendingReportsComponentComponent', () => {
  let component: ShowPendingReportsComponentComponent;
  let fixture: ComponentFixture<ShowPendingReportsComponentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ShowPendingReportsComponentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ShowPendingReportsComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
