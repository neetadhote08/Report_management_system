import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { ReportService } from '../report.service';
import { Report } from '../reports';

@Component({
  selector: 'app-show-pending-reports-component',
  templateUrl: './show-pending-reports-component.component.html',
  styleUrls: ['./show-pending-reports-component.component.css']
})
export class ShowPendingReportsComponentComponent implements OnInit {

  constructor(private router:Router,private reportService: ReportService) { }

  pendingreports: Observable<Report[]>

  ngOnInit(): void {
    this.fetchallPendings()
  }

fetchallPendings()
{
  this.pendingreports=this.reportService.viewPendingReports();
}
/*onSubmit()
{
  this.fetchallPendings();
}*/
viewdetails(id:number)
  {
    this.router.navigate(['reports/viewreports',id]);
  }
updateStatus(id:number)
{
  this.router.navigate(["reports/updatestatus",id])
}
deleteReport(id:number)
{
  this.reportService.deleteReport(id)
  .subscribe(
    data => {
      console.log(data);
      this.reportService.viewAllReports();
    },
    error => console.log(error));
}
}
