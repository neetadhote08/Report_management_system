import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowProjectComponentComponent } from './show-project-component.component';

describe('ShowProjectComponentComponent', () => {
  let component: ShowProjectComponentComponent;
  let fixture: ComponentFixture<ShowProjectComponentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ShowProjectComponentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ShowProjectComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
