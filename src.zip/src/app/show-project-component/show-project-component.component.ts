import { Component, OnInit } from '@angular/core';
import { ProjectService } from '../project.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Project } from '../projects';


@Component({
  selector: 'app-show-project-component',
  templateUrl: './show-project-component.component.html',
  styleUrls: ['./show-project-component.component.css']
})
export class ShowProjectComponentComponent implements OnInit {

  constructor(private projectService:ProjectService, private router:Router,private route: ActivatedRoute) { }
  projects: Observable<Project[]>;
  ngOnInit(): void {
    this.fetchAllProjects();
  }

  fetchAllProjects()
  {
    
    this.projects=this.projectService.viewProjectList();
    //this.projects=Array.of(this.projects);
  }

  projectDetails(id:number)
  {
    this.router.navigate(['projects/projectdetails',id]);
  }

}
