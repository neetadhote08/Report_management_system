import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-aboutus-component',
  templateUrl: './aboutus-component.component.html',
  styleUrls: ['./aboutus-component.component.css']
})
export class AboutusComponentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
