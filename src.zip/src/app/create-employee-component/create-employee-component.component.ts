import { Component, OnInit } from '@angular/core';
import {EmployeeService} from '../employee.service';
import {Router} from '@angular/router';
import {Employee} from '../employees';

@Component({
  selector: 'app-create-employee-component',
  templateUrl: './create-employee-component.component.html',
  styleUrls: ['./create-employee-component.component.css']
})
export class CreateEmployeeComponentComponent implements OnInit {

  constructor(private employeeService: EmployeeService, private router: Router) { }

  employee: Employee=new Employee();

  ngOnInit() {
  }

 saveEmployee()
  {
    this.employeeService.addEmployee(this.employee).subscribe(data => console.log(data),error =>  console.log(error));
    this.employee=new Employee();
    this.gotoLoginPage();
  }

  onSubmit()
  {
    this.saveEmployee();
  }
  gotoLoginPage(){
    this.router.navigate(['/employees/login']);
  }

}