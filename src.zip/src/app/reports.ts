//import { Employee } from "./employees";
//import { Project } from "./projects";

export class Report{
    rid:number;
    status:string;
    description:string;
    assignedproject:{
        projid:number;
    };
    assignedMentor:{
        empid:number;
    };
    subdate:any;
    assess_date:any;

}