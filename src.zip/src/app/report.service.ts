import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';
import { Report } from './reports';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';


@Injectable({
  providedIn: 'root'
})
export class ReportService {
  private baseUrl = 'http://localhost:8080';
  constructor(private http: HttpClient) { }

  addReport(Report:Object): Observable<any>{
    return this.http.post(this.baseUrl+'/report/addreport/',Report);
  }

  updateStatus(id:number): Observable<Object>
  {
    return this.http.put(this.baseUrl+'/report/updatestatus/',{id});
  }

  viewAllReports(): Observable<any>
  {
    return this.http.get(this.baseUrl+'/report/allreports');
  }

  viewPendingReports(): Observable<any>
  {
    return this.http.get(this.baseUrl+'/report/pendingreport/');
  }

  deleteReport(id:number):Observable<Object>
  {
    return this.http.delete(this.baseUrl+'/report/deleteproduct/'+{id});
  }

  viewReport(id:number):Observable<any>
  {
    return this.http.get(this.baseUrl+'/report/viewreport/'+{id});
  }
}
