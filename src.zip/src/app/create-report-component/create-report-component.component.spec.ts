import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateReportComponentComponent } from './create-report-component.component';

describe('CreateReportComponentComponent', () => {
  let component: CreateReportComponentComponent;
  let fixture: ComponentFixture<CreateReportComponentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CreateReportComponentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateReportComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
