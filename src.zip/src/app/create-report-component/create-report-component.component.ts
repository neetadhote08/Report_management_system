import { Component, OnInit } from '@angular/core';
import { ReportService } from '../report.service'
import { Router } from '@angular/router';
import { Report } from '../reports';

@Component({
  selector: 'app-create-report-component',
  templateUrl: './create-report-component.component.html',
  styleUrls: ['./create-report-component.component.css']
})
export class CreateReportComponentComponent implements OnInit {

  constructor(private reportService:ReportService,private router:Router) { }

  report : Report=new Report();

  ngOnInit(): void {
  }

saveReport()
{
  this.reportService.addReport(this.report).subscribe(data=>{console.log(data)
  this.report=data},error=>console.log(error));
  console.log(this.report);
  this.report=new Report();
  this.gotoReportList();
}
onSubmit()
{
  this.saveReport();
}
gotoReportList()
{
  this.router.navigate(['/reports/viewallreports']);
}
}
