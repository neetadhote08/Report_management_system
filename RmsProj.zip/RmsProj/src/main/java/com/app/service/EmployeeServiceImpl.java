package com.app.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dao.IEmployeeDao;
import com.app.pojos.Employee;

@Service
@Transactional
public class EmployeeServiceImpl implements IEmployeeService {
	
	@Autowired
	IEmployeeDao empDao;

	@Override
	public Employee registerEmployee(Employee newEmp) {
		// TODO Auto-generated method stub
		
		Employee emp= empDao.registerEmployee(newEmp);
		System.out.println("in emp service register"+newEmp);
		return emp;
	}

	@Override
	public Employee validateEmployee(String email, String password) {
		// TODO Auto-generated method stub
		return empDao.validateEmployee(email, password);
	}

	@Override
	public Employee updateRole(int eid, String role) {
		// TODO Auto-generated method stub
		return empDao.updateRole(eid, role);
	}

	@Override
	public Employee changePassword(String email, String oldpass, String newpass) {
		// TODO Auto-generated method stub
		return empDao.changePassword(email, oldpass, newpass);
	}
	
	 @Override
	public Employee findEmployee(int eid) {
		
		return empDao.findEmployee(eid);
	}

}
