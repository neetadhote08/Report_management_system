package com.app.service;

import java.util.List;

import com.app.pojos.Project;

public interface IProjectService {
	
	Project addProject(Project proj);
	Project findProject(int projid);
	List<Project> viewAllProject();
	

}
