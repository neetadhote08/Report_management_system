package com.app.service;

import com.app.pojos.Employee;

public interface IEmployeeService {

	Employee registerEmployee(Employee newEmp);
	Employee validateEmployee(String email,String password);
	Employee updateRole(int eid,String role);
	Employee changePassword(String email,String oldpass,String newpass);
	Employee findEmployee(int eid);
	
}
