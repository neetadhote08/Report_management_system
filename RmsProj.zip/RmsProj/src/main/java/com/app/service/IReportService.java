package com.app.service;

import java.util.List;


import com.app.pojos.Report;


public interface IReportService {

	Report addReport(Report newReport);
	Report updateStatus(int rid);
	List<Report> viewAllReports();
	List<Report> viewPendingReports();
	Report deleteReport(int rid);
	Report viewReport(int rid);
	Report updateAssessDate(int rid);
	
}
