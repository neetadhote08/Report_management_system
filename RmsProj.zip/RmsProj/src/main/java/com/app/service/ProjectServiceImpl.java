package com.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dao.IProjectDao;
import com.app.pojos.Project;

@Service
@Transactional
public class ProjectServiceImpl implements IProjectService {
	@Autowired
	IProjectDao projectDao;

	@Override
	public Project addProject(Project proj) {
		projectDao.addProject(proj);
		return proj;
	}
	@Override
	public Project findProject(int projid) {
		Project proj=projectDao.findproject(projid);
		return proj;
	}
	public ProjectServiceImpl() {
		// TODO Auto-generated constructor stub
		System.out.println("project service");
	}
	@Override
	public List<Project> viewAllProject() {
		List<Project> allProj=projectDao.viewAllProjects();
		return allProj;
	}
}
