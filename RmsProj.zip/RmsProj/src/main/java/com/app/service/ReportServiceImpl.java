package com.app.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dao.IReportDao;
import com.app.pojos.Report;

@Service
@Transactional
public class ReportServiceImpl implements IReportService {
	
	@Autowired
	IReportDao reportDao;
	
	@Override
	public Report updateAssessDate(int rid) {
		// TODO Auto-generated method stub
		Report report=reportDao.updateAssessDate(rid);
		return report;
	}
	@Override
	public Report viewReport(int rid) {
		// TODO Auto-generated method stub
		Report report=reportDao.viewReport(rid);
		return report;
	}

	@Override
	public Report addReport(Report newReport) {
		reportDao.addReport(newReport);
		System.out.println("report adding service");
		return newReport;
	}

	@Override
	public Report updateStatus(int rid) {
		
		Report report=reportDao.updateStatus(rid);
		report=reportDao.updateAssessDate(report.getRid());
		System.out.println("Status updaet service");
		return report;
	}

	@Override
	public List<Report> viewAllReports() {
		List<Report> allreports=new ArrayList<Report>();
		allreports=reportDao.viewAllReport();
		return allreports;
	}

	@Override
	public List<Report> viewPendingReports() {
		List<Report> pendingreports=new ArrayList<Report>();
		pendingreports=reportDao.viewPendingReports();
		return pendingreports;
	}

	@Override
	public Report deleteReport(int rid) {
		Report report=reportDao.deleteReport(rid);
		System.out.println("delete service "+report);
		return report;
	}

	public ReportServiceImpl() {
		// TODO Auto-generated constructor stub
		System.out.println("in reportt services");
	}
}
