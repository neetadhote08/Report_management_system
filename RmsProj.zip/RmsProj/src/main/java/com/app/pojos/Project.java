package com.app.pojos;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name="Project")
public class Project {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name=" projid",nullable=false,updatable=false)
	private Integer projid;
	
	
	@Column(name ="projtitle",length=25)
	private String projtitle;
	
	@Column(name = "description",length=50)
	private String description;
	
	@Column(name ="projectspan")
	private int projectspan;
	
	@Column(name="deadline")
	private LocalDate deadline;
	
	@OneToMany(mappedBy = "project")
	@JsonIgnoreProperties("project")
	private List<Report> reports= new ArrayList<>() ;
	
	public LocalDate getDeadline() {
		return deadline;
	}
	
	public void setProjid(Integer projid) {
		this.projid = projid;
	}


	/*
	 * public void setReports(List<Report> reports) { this.reports = reports; }
	 */
	/*
	 * public List<Report> getReports() { return reports; }
	 */

	public void setReports(Report reports) {
		this.reports.add(reports);
	}

	public Project(Integer projid) {
		super();
		this.projid = projid;
	}

	public void setDeadline(LocalDate deadline) {
		this.deadline = deadline;
	}

	

	public Project() {
		System.out.println("project pojo");
		
	}

	public String getProjtitle() {
		return projtitle;
	}

	public void setProjtitle(String projtitle) {
		this.projtitle = projtitle;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getProjectspan() {
		return projectspan;
	}

	public void setProjectspan(int projectspan) {
		this.projectspan = projectspan;
	}

	public Integer getProjid() {
		return projid;
	}

	@Override
	public String toString() {
		return "Project [projid=" + projid + ", projtitle=" + projtitle + ", description=" + description
				+ ", projectspan=" + projectspan + "]";
	}
	
	

}
