package com.app.pojos;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name="Employee")
public class Employee {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="empid")
	private Integer empid;
	
	@Column(name="empname",length=35)
	private String empname;
	
	@Column(name="email",length=30,nullable = false,unique = true)
	private String email;
	
	@Column(name="password",length=25)
	private String password;
	
	@Column(name="role",length=25)
	private String role;

	@OneToMany(mappedBy = "assignedMentor")
	@JsonIgnoreProperties("assignedMentor")
	private List<Report> reports=new ArrayList<>();
	
	public Employee() {
		System.out.println("emp pojo");
	}
	
	
	public List<Report> getReports() {
		return reports;
	}


	public void setReports(List<Report> reports) 
	{ this.reports=reports; }



	public Employee(Integer empid) {
		super();
		this.empid = empid;
	}


	public Employee(String empname, String email, String password, String role, List<Report> reports) {
		super();
		this.empname = empname;
		this.email = email;
		this.password = password;
		this.role = role;
	}
	
	
	public Employee(String email, String password) {
		super();
		this.email = email;
		this.password = password;
	}
	public Integer getEmpid() {
		return empid;
	}

	public void setEmpid(Integer empid) {
		this.empid = empid;
	}

	public String getEmpname() {
		return empname;
	}

	public void setEmpname(String empname) {
		this.empname = empname;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	@Override
	public String toString() {
		return "Employee [empid=" + empid + ", empname=" + empname + ", email=" + email + ", password=" + password
				+ ", role=" + role + "]";
	}
	
	
	
	
	
	
}
