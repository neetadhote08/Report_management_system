package com.app.pojos;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

@Entity
@Table(name="Report")
public class Report {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="rid",nullable =false,updatable=false)
	private Integer rid;
	
	@Column(name="status",length=20)
	private String status;
	
	@Column(name="description",length=50)
	private String description;

	public Report(String description) {
		super();
		this.description = description;
	}

	@ManyToOne
	@JoinColumn(name = "eid",nullable = false)
	private Employee assignedMentor;
	
	

	@DateTimeFormat(pattern="yyyy-MM-dd")
	@JsonFormat(pattern="yyyy-MM-dd")
	private LocalDate subdate;
	
	@DateTimeFormat(pattern="yyyy-MM-dd")
	@JsonFormat(pattern="yyyy-MM-dd")
	private LocalDate assess_date;
	
	@ManyToOne
	@JoinColumn(name = "projid",nullable = false)
	private Project project;
	
	public Report() {
		super();
		System.out.println("in report dao");
	}

	public Report(String description, Employee assignedMentor, Project project) {
		super();
		this.description = description;
		this.assignedMentor = assignedMentor;
		this.project = project;
	}

	public Integer getRid() {
		return rid;
	}

	public void setRid(Integer rid) {
		this.rid = rid;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Employee getAssignedMentor() {
		return assignedMentor;
	}

	public void setAssignedMentor(Employee assignedMentor) {
		this.assignedMentor = assignedMentor;
	}

	public LocalDate getSubdate() {
		return subdate;
	}

	public void setSubdate(LocalDate subdate) {
		this.subdate = subdate;
	}

	public LocalDate getAssess_date() {
		return assess_date;
	}

	public void setAssess_date(LocalDate assess_date) {
		this.assess_date = assess_date;
	}

	public Project getProject() {
		return project;
	}

	public void setProject(Project project) {
		this.project = project;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	
	@Override
	public String toString() {
		return "Report [rid=" + rid + ", status=" + status + ", assignedMentor=" + assignedMentor + ", subdate="
				+ subdate + ", assess_date=" + assess_date + ", project=" + project + "]";
	}

	
	
	

	
}
	
	
	
	


