package com.app.dao;

import com.app.pojos.Employee;

public interface IEmployeeDao {
	
	Employee registerEmployee(Employee newEmp);
	Employee validateEmployee(String email,String password);
	Employee updateRole(int eid,String role);
	Employee changePassword(String email,String oldpass,String newpass);
	Employee findEmployee(int eid);
	
	//Employee findEmployeeByEmail(String email);
	

}
