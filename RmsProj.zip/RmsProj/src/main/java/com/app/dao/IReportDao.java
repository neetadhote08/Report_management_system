package com.app.dao;

import java.util.List;

import com.app.pojos.Report;

public interface IReportDao {

	Report addReport(Report newReport);
	Report updateStatus(int rid);
	List<Report> viewAllReport();
	List<Report> viewPendingReports();
	Report viewReport(int rid);
	Report deleteReport(int rid);
	Report updateAssessDate(int rid);
	
	
}
