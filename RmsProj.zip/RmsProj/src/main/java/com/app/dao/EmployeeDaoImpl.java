package com.app.dao;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.app.pojos.Employee;

@Repository
public class EmployeeDaoImpl implements IEmployeeDao {

	@PersistenceContext
	EntityManager mgr;
	
	
	@Override
	public Employee registerEmployee(Employee newEmp) {
		System.out.println("in dao regsiter"+newEmp);
		mgr.persist(newEmp);
		return newEmp;
	}


	@Override
	public Employee validateEmployee(String email, String password) {
		Employee theEmp=mgr.createQuery("select e from Employee e where e.email=:email and e.password=:pass",Employee.class).setParameter("email",email).setParameter("pass",password).getSingleResult();
		
		return theEmp;
	}
	@Override
	public Employee findEmployee(int eid) {
		Employee emp=mgr.find(Employee.class,eid);
		return emp;
	}

	@Override
	public Employee updateRole(int eid,String role) {
		Employee emp=mgr.find(Employee.class,eid);
		emp.setRole(role);
		mgr.merge(emp);
		return  emp;
	}

	public EmployeeDaoImpl() {
		System.out.println("Employee dao");
		
	}

	@Override
	public Employee changePassword(String email, String oldpass, String newpass) {
		Employee theEmp=mgr.createQuery("select e from Employee e where e.email=:email and e.password=:pass",Employee.class).setParameter("email",email).setParameter("pass",oldpass).getSingleResult();
		theEmp.setPassword(newpass);
		mgr.merge(theEmp);
		return theEmp;
	}

	
}
