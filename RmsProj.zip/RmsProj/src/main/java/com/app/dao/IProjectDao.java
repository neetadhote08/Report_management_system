package com.app.dao;

import java.util.List;

import com.app.pojos.Project;

public interface IProjectDao {
	
	Project addProject(Project proj);
	Project findproject(int projid);
	List<Project> viewAllProjects();
	
	

}
