package com.app.dao;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.aspectj.weaver.NewParentTypeMunger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.app.pojos.Project;
import com.app.pojos.Report;

@Repository
public class ReportDaoImpl implements IReportDao {
	
	@PersistenceContext
	EntityManager mgr;
	
	@Autowired
	IEmployeeDao empdao;
	
	@Autowired
	IProjectDao projDao;
	

	@Override
	public Report addReport(Report newReport) {
		newReport.setSubdate(LocalDate.now());
		newReport.setAssess_date(null);
		newReport.setAssignedMentor(empdao.findEmployee(newReport.getAssignedMentor().getEmpid()));
		
		newReport.setProject(projDao.findproject(newReport.getProject().getProjid()));
		mgr.persist(newReport);
		//newReport.getAssignedMentor().setReports(newReport);
		//newReport.getProject().setReports(newReport);
		
		System.out.println("report added "+newReport);
		return newReport;
	}
	
	@Override
	public Report deleteReport(int rid) {
		Report report=mgr.find(Report.class,rid);
		mgr.remove(report);
		System.out.println("Delete report"+report);
		return report;
	}
	@Override
	public Report updateStatus(int rid) {
		Report report=mgr.find(Report.class, rid);
		
		report.setStatus("reviewed");
		mgr.merge(report);
		System.out.println("Status updated"+report);
		// TODO Auto-generated method stub
		return report;
	}
	@Override
	public List<Report> viewAllReport() {
		List<Report> allreport=new ArrayList<Report>();
		allreport=mgr.createQuery("select r from Report r",Report.class).getResultList();
		return allreport;
	}
	@Override
	public List<Report> viewPendingReports() {
		List<Report> pendingReports=new ArrayList<Report>();
		//String status="pending";
		pendingReports=mgr.createQuery("select r from Report r where r.status=:stat",Report.class).setParameter("stat","pending").getResultList(); 
		System.out.println("reports fetched");
		return pendingReports;
	}
	public ReportDaoImpl() {
		System.out.println("In reportDao cnstr");
	}
	
	@Override
	public Report updateAssessDate(int rid) {
		Report theReport=mgr.find(Report.class,rid);
		theReport.setAssess_date(LocalDate.now());
		mgr.merge(theReport);
		
		return theReport;
	}
	
	@Override
	public Report viewReport(int rid) {
		Report report=mgr.find(Report.class,rid);
		return report ;
	}
}
