package com.app.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.app.pojos.Project;

@Repository
public class ProjectDaoImpl implements IProjectDao {
	
	@PersistenceContext
	EntityManager mgr;

	@Override
	public Project addProject(Project proj) {
		
		mgr.persist(proj);
		System.out.println("project added");
		return proj;
	}

	 @Override
	public Project findproject(int projid)
	{
		Project proj=mgr.find(Project.class,projid);
		System.out.println("retrived proj"+proj);
		return proj ;
	}
	 
	 public ProjectDaoImpl() {
		// TODO Auto-generated constructor stub
		 System.out.println("in Proj dao");
	}
	 
	 @Override
	public List<Project> viewAllProjects() {
		// TODO Auto-generated method stub
		 List<Project> allProj=new ArrayList<Project>();
		 allProj=mgr.createQuery("select p from Project p",Project.class).getResultList();
		return allProj;
	}
	 
}
