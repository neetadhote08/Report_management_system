package com.app.controller;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.pojos.Employee;
import com.app.pojos.Report;
import com.app.service.IEmployeeService;
import com.app.service.IProjectService;
import com.app.service.IReportService;

@RestController
@RequestMapping("/report")
@CrossOrigin
public class ReportController {
	
	@Autowired
	IReportService service;
	@Autowired
	IEmployeeService empservice;
	@Autowired
	IProjectService projservice;
	
	public ReportController() {
		// TODO Auto-generated constructor stub
		System.out.println("in report controller");
	}
	
	@PostMapping("/addreport")
	public ResponseEntity<?> addReport(@RequestBody Report newReport)
	{
		try
		{
			Report report=service.addReport(newReport);
			System.out.println("report added"+report);
			return new ResponseEntity<>(report,HttpStatus.CREATED);
		}
		catch(RuntimeException err)
		{
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
	}
	
	@PutMapping("/updatestatus/{rid}")
	public ResponseEntity<?> updateStatus(@PathVariable int rid )
	{
		Report report=service.updateStatus(rid);
		if(report!=null)
		{
			return new ResponseEntity<>(report,HttpStatus.OK);
		}
		else
		{
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
			
	}
	@GetMapping("/allreports")
	public ResponseEntity<?> viewAllReports()
	{
		List<Report> allreports=service.viewAllReports();
		
		if(allreports.isEmpty())
		{
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
		else
		{
			return new ResponseEntity<>(allreports,HttpStatus.OK);
		}
		
	}
	
	@GetMapping("/pendingreport")
	public ResponseEntity<?> viewPendingReports()
	{
		List<Report> pendingreport=service.viewPendingReports();
		
		if(pendingreport.isEmpty())
		{
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
		else
		{
			return new ResponseEntity<>(pendingreport,HttpStatus.OK);
		}
	}
	
	@DeleteMapping("/deleteproduct/{rid}")
	public ResponseEntity<?> deleteReport(@PathVariable int rid)
	{
		Report report=service.deleteReport(rid);
		if(report!=null)
		{
			return new ResponseEntity<>(report,HttpStatus.OK);
		}
		else
		{
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}
	@CrossOrigin
	@GetMapping("/viewreport/{rid}")
	public ResponseEntity<?> viewReport(@PathVariable int rid)
	{
		Report report=service.viewReport(rid);
		if(report!=null)
		{
			return new ResponseEntity<>(report,HttpStatus.OK);
		}
		else
		{
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
	}
}
	


