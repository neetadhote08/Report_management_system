package com.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.app.pojos.Employee;
import com.app.service.IEmployeeService;


@RestController
@RequestMapping("/employee")
@CrossOrigin
public class EmployeeController {
	
	@Autowired
	IEmployeeService service;
	
	public EmployeeController() {
		// TODO Auto-generated constructor stub
		System.out.println("in emp cntrlr");
	}
	
	@PostMapping("/login")
	public ResponseEntity<?> loginEmployee(@RequestBody Employee emp)
	{
		Employee empre=service.validateEmployee(emp.getEmail(),emp.getPassword());
		if(emp!=null)
		{
		return new ResponseEntity<>(empre,HttpStatus.ACCEPTED);
		}
		else
		{
			return new ResponseEntity<>(HttpStatus.NOT_ACCEPTABLE);
		}
	}
	
	@PutMapping("/changepass/{newpass}")
	public ResponseEntity<?> changePassword(@RequestBody Employee theEmp,@PathVariable String newpass)
	{
		Employee emp=service.changePassword(theEmp.getEmail(),theEmp.getPassword(), newpass);
		if(emp!=null)
		{
		return new ResponseEntity<>(emp,HttpStatus.OK);
		}
		else
		{
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}
	
	@PutMapping("/updaterole/{role}")
	public ResponseEntity<?> updateRole(@RequestBody Employee theEmp,@PathVariable String role)
	{
		Employee emp=service.updateRole(theEmp.getEmpid(),role);
		if(emp!=null)
		{
			return new ResponseEntity<>(emp,HttpStatus.OK);
			
		}
		else
		{
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}
	
	@PostMapping("/register")
	public ResponseEntity<?> registerEmployee(@RequestBody Employee newEmp)
	{
	
		try
		{
			System.out.println("in registeremp"+newEmp+"This is created");
			Employee emp=newEmp;
			emp=service.registerEmployee(newEmp);
			
			return new ResponseEntity<>(emp,HttpStatus.CREATED);
			
		}
		catch(RuntimeException err)
		{
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	

}
