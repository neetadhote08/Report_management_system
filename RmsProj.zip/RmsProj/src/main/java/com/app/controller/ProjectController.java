package com.app.controller;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.pojos.Project;
import com.app.service.IProjectService;

@CrossOrigin
@RestController
@RequestMapping("/project")
public class ProjectController {
	
	@Autowired 
	IProjectService service;
	
	public ProjectController() {
		
		// TODO Auto-generated constructor stub
		System.out.println("project controller");
	}
	
	@PostMapping("/addproject")
	public ResponseEntity<?> addProject(@RequestBody Project proj)
	{
		try
		{
			
			Project newProj=service.addProject(proj);
			return new ResponseEntity<>(newProj,HttpStatus.CREATED);
			
		}
		catch(RuntimeException err)
		{
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	
	@GetMapping("/viewprojects")
	public ResponseEntity<?> viewAllProject()
	{
		List<Project> allProj=service.viewAllProject();
		
		if(allProj!=null)
		{
			return new  ResponseEntity<>(allProj,HttpStatus.OK);
		}
		else
		{
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
	}
	
	@GetMapping("/viewproj/{pid}")
	public ResponseEntity<?> viewProject(@PathVariable int id)
	{
		Project proj=service.findProject(id);
		if(proj!=null)
		{
			return new ResponseEntity<>(proj,HttpStatus.OK);
		}
		else {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
	}

}
