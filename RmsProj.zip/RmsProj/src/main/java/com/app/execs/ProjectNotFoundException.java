package com.app.execs;

public class ProjectNotFoundException extends RuntimeException{
	
	public ProjectNotFoundException(String err)
	{
		super(err);
	}

}
