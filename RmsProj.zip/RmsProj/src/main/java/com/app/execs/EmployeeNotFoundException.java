package com.app.execs;

public class EmployeeNotFoundException extends RuntimeException {
	
	 public EmployeeNotFoundException(String err)
	 {
		 super(err);
	 }

}
