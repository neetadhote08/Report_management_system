package com.app.execs;

public class ReportNotFoundException  extends RuntimeException{
	
	public ReportNotFoundException(String err)
	{
		super(err);
	}
	

}
