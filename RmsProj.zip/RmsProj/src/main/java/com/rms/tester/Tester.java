package com.rms.tester;

import com.app.dao.EmployeeDaoImpl;
import com.app.service.EmployeeServiceImpl;
import com.app.pojos.Employee;

public class Tester {
	public static void main(String []args)
	{
		Employee emp=new Employee("Mayuri Chitte","maya@gmail.com","maya123","mentor",null);
		EmployeeDaoImpl ed=new  EmployeeDaoImpl();
		ed.registerEmployee(emp);
	}

	
	
	
	
}
